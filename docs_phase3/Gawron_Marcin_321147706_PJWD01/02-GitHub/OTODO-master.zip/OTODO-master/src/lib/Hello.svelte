<!--    This is the welcoming component
-->

<section class="hello">
    <h1>OTODO</h1>
    <h2>Your new way to remember</h2>
</section>

<style>
    .hello {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;        
    }

    h1 {
        font-family: 'Courier New', Courier, monospace;
        font-weight: 1000;
        font-size: 50px;        
        margin-bottom: 5px;
    }

    h2 {
        font-family: 'Courier New', Courier, monospace;
        font-weight: 500;
        margin-top: 5px;
    }
</style>