# OTODO
Are you dualbooting and need your task list on both systems?
Or maybe to you want it synchronized between PCs and smartphones?

Look no more. OTODO is a cloud-based TODO list manager.

## THIS IS A WORK IN PROGRESS.

To use this application in its current state, you'll need npm and node installed.

# Installing
1. Clone the repository
2. Run `npm install`

# Running
1. Run `npm run build`
2. Run `node server/server.js`

# Testing
1. Run `npm test`